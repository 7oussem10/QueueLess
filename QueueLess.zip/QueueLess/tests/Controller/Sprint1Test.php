<?php

namespace App\Tests\Controller;

use App\Entity\User;
use App\Entity\Counter;
use App\Entity\Service;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class Sprint1Test extends WebTestCase
{
    private function entityManager(): EntityManagerInterface
    {
        return static::getContainer()->get(EntityManagerInterface::class);
    }

    private function loginAs($client, string $email, string $password): void
    {
        $crawler = $client->request('GET', '/login');
        $form = $crawler->selectButton('Se connecter')->form([
            'email' => $email,
            'password' => $password,
        ]);
        $client->submit($form);
    }

    public function testPublicPagesAndServiceConsultation(): void
    {
        $client = static::createClient();

        $client->request('GET', '/');
        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('body', 'QueueLess');

        $client->request('GET', '/services');
        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h2', 'Services disponibles');
    }

    public function testClientRegistration(): void
    {
        $client = static::createClient();
        $email = 'client_' . bin2hex(random_bytes(4)) . '@queueless.local';
        $crawler = $client->request('GET', '/register');
        $form = $crawler->selectButton('Finaliser mon inscription')->form([
            'registration_form[firstName]' => 'Nadia',
            'registration_form[lastName]' => 'Test',
            'registration_form[email]' => $email,
            'registration_form[phoneNumber]' => '22112233',
            'registration_form[plainPassword][first]' => 'Client123!',
            'registration_form[plainPassword][second]' => 'Client123!',
        ]);

        $client->submit($form);
        $this->assertResponseRedirects('/login');

        $user = $this->entityManager()->getRepository(User::class)->findOneBy(['email' => $email]);
        $this->assertNotNull($user);
        $this->assertContains('ROLE_CLIENT', $user->getRoles());
        $this->assertNotSame('Client123!', $user->getPassword());
    }

    public function testClientRegistrationValidation(): void
    {
        $client = static::createClient();
        $crawler = $client->request('GET', '/register');
        $form = $crawler->selectButton('Finaliser mon inscription')->form([
            'registration_form[firstName]' => '',
            'registration_form[lastName]' => 'Test',
            'registration_form[email]' => 'invalid_' . bin2hex(random_bytes(3)) . '@queueless.local',
            'registration_form[plainPassword][first]' => 'Client123!',
            'registration_form[plainPassword][second]' => 'Client123!',
        ]);

        $client->submit($form);
        $this->assertResponseStatusCodeSame(422);
        $this->assertSelectorTextContains('body', 'Veuillez saisir votre prénom.');
    }

    public function testAuthenticationWithInvalidCredentials(): void
    {
        $client = static::createClient();
        $crawler = $client->request('GET', '/login');
        $form = $crawler->selectButton('Se connecter')->form([
            'email' => 'client@queueless.local',
            'password' => 'incorrect',
        ]);

        $client->submit($form);
        $this->assertResponseRedirects('/login');
        $client->followRedirect();
        $this->assertSelectorTextContains('.alert-danger', 'Identifiants invalides');
    }

    public function testClientAuthenticationAndRedirection(): void
    {
        $client = static::createClient();
        $this->loginAs($client, 'client@queueless.local', 'Client123!');
        $this->assertResponseRedirects('/client');

        $client->followRedirect();
        $this->assertSelectorTextContains('h2', 'Bienvenue');
    }

    public function testAgentAuthenticationAndPermissions(): void
    {
        $client = static::createClient();
        $this->loginAs($client, 'agent@queueless.local', 'Agent123!');
        $this->assertResponseRedirects('/agent');

        $client->followRedirect();
        $this->assertSelectorTextContains('h2', 'Poste Agent');

        $client->request('GET', '/admin');
        $this->assertResponseStatusCodeSame(403);

        $client->request('GET', '/client');
        $this->assertResponseStatusCodeSame(403);
    }

    public function testAdminAuthenticationAndDashboard(): void
    {
        $client = static::createClient();
        $this->loginAs($client, 'admin@queueless.local', 'Admin123!');
        $this->assertResponseRedirects('/admin');

        $client->followRedirect();
        $this->assertSelectorTextContains('h2', 'Tableau de bord de pilotage');

        $client->request('GET', '/client');
        $this->assertResponseStatusCodeSame(403);
    }

    public function testAdminUserManagementAndRoleAssignment(): void
    {
        $client = static::createClient();
        $admin = $this->entityManager()->getRepository(User::class)->findOneBy(['email' => 'admin@queueless.local']);
        $this->assertNotNull($admin);

        $target = new User();
        $target->setEmail('role_test_' . bin2hex(random_bytes(4)) . '@queueless.local')
            ->setFirstName('Rôle')
            ->setLastName('Test')
            ->setPassword('test-password')
            ->setRoles(['ROLE_CLIENT']);
        $this->entityManager()->persist($target);
        $this->entityManager()->flush();
        $targetId = $target->getId();

        $client->loginUser($admin);

        try {
            $client->request('GET', '/admin/users');
            $this->assertResponseIsSuccessful();
            $this->assertSelectorTextContains('h2', 'Gestion des comptes utilisateurs');

            $crawler = $client->request('GET', '/admin/users/' . $targetId . '/edit');
            $this->assertResponseIsSuccessful();
            $this->assertSelectorTextContains('body', 'Attribution des rôles');

            $csrfToken = $crawler->filter('input[type="hidden"]')->first()->attr('value');
            $client->request('POST', '/admin/users/' . $targetId . '/edit', [
                'user_edit_form' => [
                    '_token' => $csrfToken,
                    'firstName' => 'Rôle',
                    'lastName' => 'Test',
                    'email' => 'role_test_' . $targetId . '@queueless.local',
                    'phoneNumber' => '',
                    'roles' => ['ROLE_AGENT'],
                    'isActive' => '1',
                    'newPassword' => '',
                ],
            ]);
            $this->assertResponseRedirects('/admin/users');

            $updated = $this->entityManager()->getRepository(User::class)->find($targetId);
            $this->assertContains('ROLE_AGENT', $updated->getRoles());
            $this->assertNotContains('ROLE_CLIENT', $updated->getRoles());

            $crawler = $client->request('GET', '/admin/users/' . $targetId . '/edit');
            $csrfToken = $crawler->filter('input[type="hidden"]')->first()->attr('value');
            $client->request('POST', '/admin/users/' . $targetId . '/edit', [
                'user_edit_form' => [
                    '_token' => $csrfToken,
                    'firstName' => 'Rôle',
                    'lastName' => 'Test',
                    'email' => 'role_test_' . $targetId . '@queueless.local',
                    'phoneNumber' => '',
                    'roles' => [],
                    'isActive' => '1',
                    'newPassword' => '',
                ],
            ]);
            $this->assertResponseIsSuccessful();
            $this->assertSelectorTextContains('body', 'Attribuez au moins un rôle');

            $entityManager = $this->entityManager();
            $entityManager->clear();
            $updated = $entityManager->getRepository(User::class)->find($targetId);
            $this->assertContains('ROLE_AGENT', $updated->getRoles());
        } finally {
            $entityManager = $this->entityManager();
            $testUser = $entityManager->getRepository(User::class)->find($targetId);
            if ($testUser) {
                $entityManager->remove($testUser);
                $entityManager->flush();
            }
        }
    }

    public function testAdminServiceManagement(): void
    {
        $client = static::createClient();
        $admin = $this->entityManager()->getRepository(User::class)->findOneBy(['email' => 'admin@queueless.local']);
        $client->loginUser($admin);

        $client->request('GET', '/admin/services');
        $this->assertResponseIsSuccessful();
        $this->assertSelectorExists('table');

        $crawler = $client->request('GET', '/admin/services/new');
        $this->assertResponseIsSuccessful();
        $code = 'T' . strtoupper(bin2hex(random_bytes(3)));
        $form = $crawler->selectButton('Créer le service')->form([
            'service_form[name]' => 'Service test ' . $code,
            'service_form[code]' => $code,
            'service_form[description]' => 'Test de création du service.',
            'service_form[estimatedDurationMinutes]' => '15',
        ]);
        $client->submit($form);
        $this->assertResponseRedirects('/admin/services');

        $service = $this->entityManager()->getRepository(Service::class)->findOneBy(['code' => $code]);
        $this->assertNotNull($service);
        $this->entityManager()->remove($service);
        $this->entityManager()->flush();
    }

    public function testAdminCounterManagement(): void
    {
        $client = static::createClient();
        $admin = $this->entityManager()->getRepository(User::class)->findOneBy(['email' => 'admin@queueless.local']);
        $client->loginUser($admin);

        $client->request('GET', '/admin/counters');
        $this->assertResponseIsSuccessful();
        $this->assertSelectorExists('table');

        $service = $this->entityManager()->getRepository(Service::class)->findOneBy(['code' => 'ACC']);
        $this->assertNotNull($service);
        $crawler = $client->request('GET', '/admin/counters/new');
        $this->assertResponseIsSuccessful();
        $code = 'T' . strtoupper(bin2hex(random_bytes(3)));
        $form = $crawler->selectButton('Créer le guichet')->form([
            'counter_form[name]' => 'Guichet test ' . $code,
            'counter_form[code]' => $code,
            'counter_form[service]' => (string) $service->getId(),
        ]);
        $client->submit($form);
        $this->assertResponseRedirects('/admin/counters');

        $counter = $this->entityManager()->getRepository(Counter::class)->findOneBy(['code' => $code]);
        $this->assertNotNull($counter);
        $this->entityManager()->remove($counter);
        $this->entityManager()->flush();
    }
}
