<?php

namespace App\Tests\Controller;

use App\Entity\Appointment;
use App\Entity\Service;
use App\Entity\ServiceSchedule;
use App\Repository\AppointmentRepository;
use App\Repository\ServiceRepository;
use App\Repository\ServiceScheduleRepository;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;
use Symfony\Component\Validator\Validator\ValidatorInterface;

/**
 * Sprint 3 – Gestion des Rendez-vous
 *
 * US08: Consulter les créneaux disponibles
 * US09: Réserver un rendez-vous
 * US10: Consulter ses rendez-vous
 * US11: Annuler un rendez-vous
 * US21: Consulter les rendez-vous du jour
 * US28: Configurer les horaires des services
 * BR07: Créneau déjà réservé
 * BR08: Client ne peut voir que ses propres rendez-vous
 * BR09: Annulation libère le créneau
 */
class Sprint3Test extends WebTestCase
{
    private static string $clientEmail    = 'client@queueless.local';
    private static string $agentEmail     = 'agent@queueless.local';
    private static string $adminEmail     = 'admin@queueless.local';

    private function getEntityManager(): EntityManagerInterface
    {
        return static::getContainer()->get(EntityManagerInterface::class);
    }

    /**
     * Remove test appointments to isolate tests.
     */
    private function cleanTestAppointments(): void
    {
        $conn = $this->getEntityManager()->getConnection();
        $conn->executeStatement("DELETE FROM appointment WHERE appointment_reference LIKE 'RDV-%'");
    }

    /**
     * Get a next-business-day date string (Mon-Fri) for slot testing.
     */
    private function getNextWeekday(int $daysAhead = 1): \DateTime
    {
        $date = new \DateTime('+' . $daysAhead . ' day');
        $dow = (int) $date->format('N');
        if ($dow === 6) {       // Saturday → Monday
            $date->modify('+2 days');
        } elseif ($dow === 7) { // Sunday → Monday
            $date->modify('+1 day');
        }
        return $date;
    }

    public function testServiceScheduleRejectsClosingBeforeOpening(): void
    {
        $schedule = new ServiceSchedule();
        $schedule->setOpeningTime(new \DateTime('09:00'));
        $schedule->setClosingTime(new \DateTime('08:00'));

        $errors = static::getContainer()->get(ValidatorInterface::class)->validate($schedule);
        $this->assertGreaterThan(0, count($errors));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // US28 – Admin configures service schedules
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * US28: Admin can list schedules and edit a schedule.
     */
    public function testAdminConfiguresServiceSchedule(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        $admin = $userRepo->findOneBy(['email' => self::$adminEmail]);
        $this->assertNotNull($admin, 'Admin user must exist');
        $browser->loginUser($admin);

        // US28: Access schedule index
        $browser->request('GET', '/admin/schedules');
        $this->assertResponseIsSuccessful('Admin schedule list page failed');
        $this->assertSelectorExists('h1, h3, table', 'Schedule list must have heading or table');

        // Get a service to test schedule
        /** @var ServiceRepository $serviceRepo */
        $serviceRepo = static::getContainer()->get(ServiceRepository::class);
        /** @var ServiceScheduleRepository $scheduleRepo */
        $scheduleRepo = static::getContainer()->get(ServiceScheduleRepository::class);
        $service = $serviceRepo->findOneBy(['isActive' => true]);
        $this->assertNotNull($service, 'Must have at least one active service');

        // Access schedule by service
        $browser->request('GET', '/admin/schedules/service/' . $service->getId());
        $this->assertResponseIsSuccessful('Admin schedule by service page failed');

        // Edit the existing Monday schedule through the route exposed by the page.
        $schedule = $scheduleRepo->findScheduleForDay($service, 1);
        $this->assertNotNull($schedule, 'Monday schedule must exist');
        $browser->request('GET', '/admin/schedules/' . $schedule->getId() . '/edit');
        $this->assertResponseIsSuccessful('Admin schedule edit page failed');

        // Schedule edit form must exist
        $crawler = $browser->getCrawler();
        $formExists = $crawler->filter('form')->count() > 0;
        $this->assertTrue($formExists, 'Schedule edit page must have a form');

        // Submit the form with valid data
        $form = $crawler->selectButton('Enregistrer')->form([
            'service_schedule_form[openingTime]' => '08:30',
            'service_schedule_form[closingTime]' => '16:30',
            'service_schedule_form[slotDurationMinutes]' => '20',
            'service_schedule_form[isActive]' => '1',
        ]);
        $browser->submit($form);
        $this->assertResponseRedirects();
        $browser->followRedirect();
        $this->assertResponseIsSuccessful('After saving schedule, redirect target must be accessible');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // US08 – Client views available slots
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * US08: Client can view available appointment slots for a service.
     */
    public function testClientViewsAvailableSlots(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        $clientUser = $userRepo->findOneBy(['email' => self::$clientEmail]);
        $this->assertNotNull($clientUser, 'Client user must exist');
        $browser->loginUser($clientUser);

        // US08: Default slots page
        $browser->request('GET', '/client/appointments/slots');
        $this->assertResponseIsSuccessful('Client appointment slots page failed');
        $this->assertSelectorExists('h1, h2, h3', 'Slots page must have a heading');

        // US08: Slots for a specific service and next weekday
        /** @var ServiceRepository $serviceRepo */
        $serviceRepo = static::getContainer()->get(ServiceRepository::class);
        $service = $serviceRepo->findOneBy(['isActive' => true]);
        $this->assertNotNull($service, 'Must have at least one active service');

        $nextWeekday = $this->getNextWeekday();
        $dateStr = $nextWeekday->format('Y-m-d');

        $browser->request('GET', '/client/appointments/slots?service_id=' . $service->getId() . '&date=' . $dateStr);
        $this->assertResponseIsSuccessful('Client appointment slots with filter failed');
        $this->assertSelectorExists('form, .card, table, .btn', 'Slots page must display content');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // US09 – Client books an appointment
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * US09: Client can book an appointment on an available slot.
     */
    public function testClientBooksAppointment(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        $clientUser = $userRepo->findOneBy(['email' => self::$clientEmail]);
        $this->assertNotNull($clientUser);
        $browser->loginUser($clientUser);

        // Get a service and schedule with active slots
        /** @var ServiceRepository $serviceRepo */
        $serviceRepo = static::getContainer()->get(ServiceRepository::class);
        /** @var ServiceScheduleRepository $scheduleRepo */
        $scheduleRepo = static::getContainer()->get(ServiceScheduleRepository::class);

        $service = $serviceRepo->findOneBy(['isActive' => true]);
        $this->assertNotNull($service, 'Must have at least one active service');

        // Find a weekday that has a schedule
        $nextWeekday = $this->getNextWeekday(1);
        $dow = (int) $nextWeekday->format('N');
        $schedule = $scheduleRepo->findScheduleForDay($service, $dow);

        if (!$schedule || !$schedule->isActive()) {
            $nextWeekday = $this->getNextWeekday(3);
            $dow = (int) $nextWeekday->format('N');
            $schedule = $scheduleRepo->findScheduleForDay($service, $dow);
        }
        $this->assertNotNull($schedule, 'Service must have a schedule for the test weekday');
        $this->assertTrue($schedule->isActive(), 'Schedule must be active');

        $dateStr = $nextWeekday->format('Y-m-d');
        $slotTime = $schedule->getOpeningTime()->format('H:i');

        // Get the CSRF token from the slots page
        $crawler = $browser->request('GET', '/client/appointments/slots?service_id=' . $service->getId() . '&date=' . $dateStr);
        $this->assertResponseIsSuccessful();

        // Submit booking via POST
        $csrfToken = $crawler->filter('form[action="/client/appointments/book"] input[name="_token"]')->first()->attr('value');

        $browser->request('POST', '/client/appointments/book', [
            '_token'     => $csrfToken,
            'service_id' => $service->getId(),
            'date'       => $dateStr,
            'time'       => $slotTime,
            'notes'      => 'Test Sprint3 booking',
        ]);

        // Should redirect to appointment show page
        $this->assertResponseRedirects();
        $browser->followRedirect();
        $this->assertResponseIsSuccessful('Appointment show page after booking failed');

        // Verify: reference appears on the page
        $content = $browser->getResponse()->getContent();
        $this->assertStringContainsString('RDV-', $content, 'Appointment reference must appear on show page');

        // Verify appointment persisted in DB
        /** @var AppointmentRepository $aptRepo */
        $aptRepo = static::getContainer()->get(AppointmentRepository::class);
        $em = $this->getEntityManager();
        $em->clear();
        $appointments = $aptRepo->findByClient($clientUser);
        $this->assertNotEmpty($appointments, 'Appointment must be persisted in database');

        $latest = $appointments[0];
        $this->assertEquals(Appointment::STATUS_CONFIRMED, $latest->getStatus(), 'Appointment must be confirmed');
        $this->assertStringStartsWith('RDV-', $latest->getAppointmentReference(), 'Reference must start with RDV-');
        $this->assertEquals($service->getId(), $latest->getService()->getId());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // BR07 – Client cannot book an already reserved slot
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * BR07: Booking the same slot twice must fail with an error message.
     */
    public function testClientCannotBookAlreadyReservedSlot(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        $clientUser = $userRepo->findOneBy(['email' => self::$clientEmail]);
        $browser->loginUser($clientUser);

        /** @var ServiceRepository $serviceRepo */
        $serviceRepo = static::getContainer()->get(ServiceRepository::class);
        /** @var ServiceScheduleRepository $scheduleRepo */
        $scheduleRepo = static::getContainer()->get(ServiceScheduleRepository::class);

        $service = $serviceRepo->findOneBy(['isActive' => true]);
        $nextWeekday = $this->getNextWeekday(2);
        $dow = (int) $nextWeekday->format('N');
        $schedule = $scheduleRepo->findScheduleForDay($service, $dow);

        if (!$schedule || !$schedule->isActive()) {
            $nextWeekday = $this->getNextWeekday(4);
            $dow = (int) $nextWeekday->format('N');
            $schedule = $scheduleRepo->findScheduleForDay($service, $dow);
        }
        $this->assertNotNull($schedule, 'Must have an active schedule for BR07 test');

        $dateStr = $nextWeekday->format('Y-m-d');
        $slotTime = $schedule->getOpeningTime()->format('H:i');

        // First booking
        $crawler = $browser->request('GET', '/client/appointments/slots?service_id=' . $service->getId() . '&date=' . $dateStr);
        $csrfToken = $crawler->filter('form[action="/client/appointments/book"] input[name="_token"]')->first()->attr('value');
        $browser->request('POST', '/client/appointments/book', [
            '_token'     => $csrfToken,
            'service_id' => $service->getId(),
            'date'       => $dateStr,
            'time'       => $slotTime,
            'notes'      => 'First booking',
        ]);
        $this->assertResponseRedirects();

        // Second booking – same slot → must fail
        $crawler = $browser->request('GET', '/client/appointments/slots?service_id=' . $service->getId() . '&date=' . $dateStr);
        $csrfToken2 = $crawler->filter('form[action="/client/appointments/book"] input[name="_token"]')->first()->attr('value');
        $browser->request('POST', '/client/appointments/book', [
            '_token'     => $csrfToken2,
            'service_id' => $service->getId(),
            'date'       => $dateStr,
            'time'       => $slotTime,
            'notes'      => 'Duplicate booking',
        ]);

        // Must redirect (error flash)
        $this->assertResponseRedirects();
        $browser->followRedirect();
        $pageContent = $browser->getResponse()->getContent();
        $this->assertStringContainsString('déjà réservé', $pageContent, 'BR07: Duplicate booking must show error');
    }

    public function testClientCannotBookTimeOutsideAvailableSlots(): void
    {
        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        /** @var ServiceRepository $serviceRepo */
        $serviceRepo = static::getContainer()->get(ServiceRepository::class);
        /** @var ServiceScheduleRepository $scheduleRepo */
        $scheduleRepo = static::getContainer()->get(ServiceScheduleRepository::class);
        /** @var \App\Service\AppointmentManager $appointmentManager */
        $appointmentManager = static::getContainer()->get(\App\Service\AppointmentManager::class);

        $client = $userRepo->findOneBy(['email' => self::$clientEmail]);
        $service = $serviceRepo->findOneBy(['isActive' => true]);
        $date = $this->getNextWeekday(2);
        $schedule = $scheduleRepo->findScheduleForDay($service, (int) $date->format('N'));
        $this->assertNotNull($schedule);

        $invalidTime = \DateTime::createFromFormat('H:i:s', $schedule->getOpeningTime()->format('H:i:s'));
        $invalidTime->modify('+5 minutes');

        $this->expectException(\InvalidArgumentException::class);
        $appointmentManager->bookAppointment($client, $service, $date, $invalidTime);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // US10 – Client views their appointments list
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * US10: Client can view their own appointment list.
     */
    public function testClientViewsOwnAppointments(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        $clientUser = $userRepo->findOneBy(['email' => self::$clientEmail]);
        $browser->loginUser($clientUser);

        $browser->request('GET', '/client/appointments');
        $this->assertResponseIsSuccessful('Client appointment list page failed');
        $this->assertSelectorExists('h1, h2, h3', 'Appointment list must have a heading');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // BR08 – Client cannot view another client's appointment
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * BR08: A client must get 403 when trying to access another client's appointment.
     */
    public function testClientCannotViewOtherClientAppointment(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        /** @var ServiceRepository $serviceRepo */
        $serviceRepo = static::getContainer()->get(ServiceRepository::class);
        /** @var ServiceScheduleRepository $scheduleRepo */
        $scheduleRepo = static::getContainer()->get(ServiceScheduleRepository::class);
        /** @var \App\Service\AppointmentManager $aptManager */
        $aptManager = static::getContainer()->get(\App\Service\AppointmentManager::class);

        $adminUser = $userRepo->findOneBy(['email' => self::$adminEmail]);
        $service = $serviceRepo->findOneBy(['isActive' => true]);
        $nextWeekday = $this->getNextWeekday(6);
        $dow = (int) $nextWeekday->format('N');
        $schedule = $scheduleRepo->findScheduleForDay($service, $dow);

        if (!$schedule || !$schedule->isActive()) {
            $nextWeekday = $this->getNextWeekday(7);
            $dow = (int) $nextWeekday->format('N');
            $schedule = $scheduleRepo->findScheduleForDay($service, $dow);
        }

        if (!$schedule || !$schedule->isActive()) {
            $this->markTestSkipped('No active schedule found for BR08 test.');
        }

        // Create appointment for admin (different user)
        $slotTime = \DateTime::createFromFormat('H:i:s', $schedule->getOpeningTime()->format('H:i:s'));
        $appointment = $aptManager->bookAppointment(
            $adminUser, $service, $nextWeekday, $slotTime, 'Admin appointment for BR08 test'
        );
        $appointmentId = $appointment->getId();

        // Log in as client (different user)
        $clientUser = $userRepo->findOneBy(['email' => self::$clientEmail]);
        $browser->loginUser($clientUser);

        // Try to access admin's appointment → must be 403
        $browser->request('GET', '/client/appointments/' . $appointmentId);
        $this->assertResponseStatusCodeSame(403, 'BR08: Client must receive 403 for another client\'s appointment');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // US11 / BR09 – Client cancels their appointment
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * US11, BR09: Client can cancel an appointment; slot becomes available again.
     */
    public function testClientCancelsAppointment(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        /** @var ServiceRepository $serviceRepo */
        $serviceRepo = static::getContainer()->get(ServiceRepository::class);
        /** @var ServiceScheduleRepository $scheduleRepo */
        $scheduleRepo = static::getContainer()->get(ServiceScheduleRepository::class);
        /** @var \App\Service\AppointmentManager $aptManager */
        $aptManager = static::getContainer()->get(\App\Service\AppointmentManager::class);

        $clientUser = $userRepo->findOneBy(['email' => self::$clientEmail]);
        $service = $serviceRepo->findOneBy(['isActive' => true]);
        $nextWeekday = $this->getNextWeekday(8);
        $dow = (int) $nextWeekday->format('N');
        $schedule = $scheduleRepo->findScheduleForDay($service, $dow);

        if (!$schedule || !$schedule->isActive()) {
            $nextWeekday = $this->getNextWeekday(9);
            $dow = (int) $nextWeekday->format('N');
            $schedule = $scheduleRepo->findScheduleForDay($service, $dow);
        }

        if (!$schedule || !$schedule->isActive()) {
            $this->markTestSkipped('No active schedule found for US11 test.');
        }

        // Create a confirmed appointment via service
        $slotTime = \DateTime::createFromFormat('H:i:s', $schedule->getOpeningTime()->format('H:i:s'));
        $appointment = $aptManager->bookAppointment($clientUser, $service, $nextWeekday, $slotTime, 'To be cancelled');
        $appointmentId = $appointment->getId();
        $this->assertEquals(Appointment::STATUS_CONFIRMED, $appointment->getStatus());

        $browser->loginUser($clientUser);

        // Get the CSRF token from the appointment cancellation form.
        $crawler = $browser->request('GET', '/client/appointments/' . $appointmentId);
        $csrfToken = $crawler->filter('form[action$="/cancel"] input[name="_token"]')->attr('value');

        $browser->request('POST', '/client/appointments/' . $appointmentId . '/cancel', [
            '_token' => $csrfToken,
        ]);
        $this->assertResponseRedirects('/client/appointments');
        $browser->followRedirect();
        $this->assertResponseIsSuccessful();

        // Check flash message
        $pageContent = $browser->getResponse()->getContent();
        $this->assertStringContainsString('annulé', $pageContent, 'US11: Cancel success message must appear');

        // Verify appointment is now cancelled in DB
        $this->getEntityManager()->clear();
        /** @var AppointmentRepository $aptRepo */
        $aptRepo = static::getContainer()->get(AppointmentRepository::class);
        $cancelled = $aptRepo->find($appointmentId);
        $this->assertNotNull($cancelled);
        $this->assertEquals(Appointment::STATUS_CANCELLED, $cancelled->getStatus(), 'US11: Status must be cancelled');

        // BR09: Slot must be free again
        $conflict = $aptRepo->findConflictingAppointment($service, $nextWeekday, $slotTime);
        $this->assertNull($conflict, 'BR09: Cancelled slot must be available for new booking');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // US21 – Agent views today's appointments
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * US21: Agent can access the daily appointments page.
     */
    public function testAgentViewsTodayAppointments(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        $agent = $userRepo->findOneBy(['email' => self::$agentEmail]);
        $this->assertNotNull($agent, 'Agent user must exist');
        $browser->loginUser($agent);

        // US21: Access today's appointments page
        $browser->request('GET', '/agent/appointments/today');
        $this->assertResponseIsSuccessful('Agent today appointments page failed');
        $this->assertSelectorExists('h1', 'Page must have an h1 heading');

        // Test with date filter
        $today = (new \DateTime())->format('Y-m-d');
        $browser->request('GET', '/agent/appointments/today?date=' . $today);
        $this->assertResponseIsSuccessful('Agent today appointments with date filter failed');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // US21 – Admin views today's appointments
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * US21: Admin can access the daily appointments page.
     */
    public function testAdminViewsTodayAppointments(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        $admin = $userRepo->findOneBy(['email' => self::$adminEmail]);
        $this->assertNotNull($admin);
        $browser->loginUser($admin);

        // US21: Access admin today's appointments
        $browser->request('GET', '/admin/appointments/today');
        $this->assertResponseIsSuccessful('Admin today appointments page failed');
        $this->assertSelectorExists('h1', 'Admin page must have an h1 heading');

        // Test with service filter
        /** @var ServiceRepository $serviceRepo */
        $serviceRepo = static::getContainer()->get(ServiceRepository::class);
        $service = $serviceRepo->findOneBy(['isActive' => true]);
        $this->assertNotNull($service);

        $today = (new \DateTime())->format('Y-m-d');
        $browser->request('GET', '/admin/appointments/today?date=' . $today . '&service_id=' . $service->getId());
        $this->assertResponseIsSuccessful('Admin today appointments with filter failed');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Access control tests
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Client must NOT access agent appointment routes (redirected or forbidden).
     */
    public function testClientCannotAccessAgentAppointmentRoutes(): void
    {
        $browser = static::createClient();
        $this->cleanTestAppointments();

        /** @var UserRepository $userRepo */
        $userRepo = static::getContainer()->get(UserRepository::class);
        $clientUser = $userRepo->findOneBy(['email' => self::$clientEmail]);
        $browser->loginUser($clientUser);

        $browser->request('GET', '/agent/appointments/today');
        $statusCode = $browser->getResponse()->getStatusCode();
        $this->assertContains($statusCode, [302, 403], 'Client must be redirected or forbidden from agent routes');
    }

    /**
     * Anonymous user must be redirected to login for all appointment routes.
     */
    public function testAnonymousUserCannotAccessAppointments(): void
    {
        $browser = static::createClient();

        $browser->request('GET', '/client/appointments');
        $this->assertResponseRedirects();
        $this->assertStringContainsString('/login', $browser->getResponse()->headers->get('Location') ?? '');

        $browser->request('GET', '/agent/appointments/today');
        $this->assertResponseRedirects();
        $this->assertStringContainsString('/login', $browser->getResponse()->headers->get('Location') ?? '');

        $browser->request('GET', '/admin/appointments/today');
        $this->assertResponseRedirects();
        $this->assertStringContainsString('/login', $browser->getResponse()->headers->get('Location') ?? '');
    }
}
