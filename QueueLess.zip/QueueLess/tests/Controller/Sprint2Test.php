<?php

namespace App\Tests\Controller;

use App\Entity\Counter;
use App\Entity\Service;
use App\Entity\Ticket;
use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class Sprint2Test extends WebTestCase
{
    private function getEntityManager(): EntityManagerInterface
    {
        return static::getContainer()->get(EntityManagerInterface::class);
    }

    private function cleanActiveTickets(): void
    {
        $em = $this->getEntityManager();
        $tickets = $em->getRepository(Ticket::class)->findBy(['status' => [Ticket::STATUS_WAITING, Ticket::STATUS_CALLED, Ticket::STATUS_IN_PROGRESS]]);
        foreach ($tickets as $t) {
            $em->remove($t);
        }
        $em->flush();
    }

    /**
     * US04 & US05: Obtenir un ticket et consulter le numéro du ticket
     */
    public function testClientObtainTicketAndConsultNumber(): void
    {
        $client = static::createClient();
        $this->cleanActiveTickets();
        $em = $this->getEntityManager();

        $clientUser = $em->getRepository(User::class)->findOneBy(['email' => 'client@queueless.local']);
        $service = $em->getRepository(Service::class)->findOneBy(['code' => 'ACC']);
        $client->loginUser($clientUser);

        // 1. Visit ticket request page
        $crawler = $client->request('GET', '/client/tickets/request');
        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h3', 'Prendre un ticket');

        // 2. Submit ticket request
        $form = $crawler->selectButton('Valider et obtenir mon ticket')->form([
            'service_id' => $service->getId(),
        ]);
        $client->submit($form);

        $this->assertResponseRedirects();
        $crawler = $client->followRedirect();

        // 3. Verify ticket view (US05)
        $this->assertSelectorTextContains('h1', 'ACC-');
        $this->assertSelectorTextContains('body', 'En attente');
        $this->assertSelectorTextContains('table', 'Accueil & Information');

        // Verify in DB
        $em->clear();
        $ticket = $em->getRepository(Ticket::class)->findOneBy(['client' => $clientUser], ['createdAt' => 'DESC']);
        $this->assertNotNull($ticket);
        $this->assertEquals(Ticket::STATUS_WAITING, $ticket->getStatus());
        $this->assertStringStartsWith('ACC-', $ticket->getTicketNumber());
    }

    /**
     * US06: Consulter sa position dans la file (Position dynamique et personnes avant)
     */
    public function testQueuePositionCalculation(): void
    {
        $client = static::createClient();
        $this->cleanActiveTickets();
        $em = $this->getEntityManager();

        $service = $em->getRepository(Service::class)->findOneBy(['code' => 'DOC']);

        // Create client A
        $clientA = new User();
        $clientA->setEmail('client_a_' . uniqid() . '@queueless.local')
            ->setFirstName('Alice')
            ->setLastName('Queue')
            ->setPassword('Pass123!')
            ->setRoles(['ROLE_USER', 'ROLE_CLIENT']);
        $em->persist($clientA);

        // Create client B
        $clientB = new User();
        $clientB->setEmail('client_b_' . uniqid() . '@queueless.local')
            ->setFirstName('Bob')
            ->setLastName('Queue')
            ->setPassword('Pass123!')
            ->setRoles(['ROLE_USER', 'ROLE_CLIENT']);
        $em->persist($clientB);

        $em->flush();

        // Ticket A
        $ticketRepo = $em->getRepository(Ticket::class);
        $ticketManager = static::getContainer()->get(\App\Service\TicketManager::class);

        $ticketA = $ticketManager->createTicket($clientA, $service);
        $ticketB = $ticketManager->createTicket($clientB, $service);

        $posA = $ticketRepo->getQueuePosition($ticketA);
        $this->assertEquals(1, $posA['position']);
        $this->assertEquals(0, $posA['peopleAhead']);

        $posB = $ticketRepo->getQueuePosition($ticketB);
        $this->assertEquals(2, $posB['position']);
        $this->assertEquals(1, $posB['peopleAhead']);

        // Check web page for client B
        $client->loginUser($clientB);
        $client->request('GET', '/client/tickets/' . $ticketB->getId());
        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('body', '1 personne(s) avant vous');
    }

    /**
     * BR04: Un client ne peut consulter que ses propres tickets
     */
    public function testClientCannotViewOtherClientTicket(): void
    {
        $client = static::createClient();
        $this->cleanActiveTickets();
        $em = $this->getEntityManager();

        $clientUser = $em->getRepository(User::class)->findOneBy(['email' => 'client@queueless.local']);
        $otherClient = new User();
        $otherClient->setEmail('other_' . uniqid() . '@queueless.local')
            ->setFirstName('Autre')
            ->setLastName('Usager')
            ->setPassword('Pass123!')
            ->setRoles(['ROLE_USER']);
        $em->persist($otherClient);

        $service = $em->getRepository(Service::class)->findOneBy(['code' => 'ACC']);
        $ticketManager = static::getContainer()->get(\App\Service\TicketManager::class);
        $otherTicket = $ticketManager->createTicket($otherClient, $service);

        $client->loginUser($clientUser);
        $client->request('GET', '/client/tickets/' . $otherTicket->getId());
        $this->assertResponseStatusCodeSame(403);
    }

    /**
     * US15: Consulter les tickets en attente
     */
    public function testAgentConsultPendingTickets(): void
    {
        $client = static::createClient();
        $em = $this->getEntityManager();
        $agent = $em->getRepository(User::class)->findOneBy(['email' => 'agent@queueless.local']);
        $client->loginUser($agent);

        $crawler = $client->request('GET', '/agent/tickets');
        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h2', 'File des tickets en attente');
    }

    /**
     * US16, US17, US18, US19: Appeler ticket suivant, consulter infos, commencer et terminer traitement
     */
    public function testFullAgentTicketProcessingLifecycle(): void
    {
        $client = static::createClient();
        $this->cleanActiveTickets();
        $em = $this->getEntityManager();

        $agent = $em->getRepository(User::class)->findOneBy(['email' => 'agent@queueless.local']);
        $service = $em->getRepository(Service::class)->findOneBy(['code' => 'ACC']);
        $counter = $em->getRepository(Counter::class)->findOneBy(['code' => 'G1']);
        $counter->setCurrentAgent($agent);
        $counter->setService($service);
        $em->flush();

        // 1. Create a waiting ticket
        $clientUser = $em->getRepository(User::class)->findOneBy(['email' => 'client@queueless.local']);
        $ticketManager = static::getContainer()->get(\App\Service\TicketManager::class);
        $ticket = $ticketManager->createTicket($clientUser, $service);

        $client->loginUser($agent);

        // 2. US16: Call next ticket
        $crawler = $client->request('GET', '/agent');
        $this->assertResponseIsSuccessful();

        $form = $crawler->selectButton('Appeler le ticket suivant (US16)')->form();
        $client->submit($form);
        $this->assertResponseRedirects('/agent');
        $crawler = $client->followRedirect();

        $em->clear();
        $calledTicket = $em->getRepository(Ticket::class)->find($ticket->getId());
        $this->assertEquals(Ticket::STATUS_CALLED, $calledTicket->getStatus());
        $this->assertEquals($agent->getId(), $calledTicket->getAgent()->getId());
        $this->assertEquals($counter->getId(), $calledTicket->getCounter()->getId());
        $this->assertNotNull($calledTicket->getCalledAt());

        // 3. US17: Consult ticket information
        $client->request('GET', '/agent/tickets/' . $calledTicket->getId());
        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h3', $calledTicket->getTicketNumber());
        $this->assertSelectorTextContains('body', $clientUser->getFullName());

        // 4. US18: Start processing ticket
        $crawler = $client->request('GET', '/agent');
        $startForm = $crawler->selectButton('Commencer le traitement (US18)')->form();
        $client->submit($startForm);
        $this->assertResponseRedirects('/agent');
        $crawler = $client->followRedirect();

        $em->clear();
        $processingTicket = $em->getRepository(Ticket::class)->find($ticket->getId());
        $this->assertEquals(Ticket::STATUS_IN_PROGRESS, $processingTicket->getStatus());
        $this->assertNotNull($processingTicket->getStartedAt());

        // 5. US19: Finish processing ticket
        $finishForm = $crawler->selectButton('Terminer le traitement (US19)')->form([
            'notes' => 'Demande traitée avec succès pour le test Scrum.',
        ]);
        $client->submit($finishForm);
        $this->assertResponseRedirects('/agent');

        $em->clear();
        $completedTicket = $em->getRepository(Ticket::class)->find($ticket->getId());
        $this->assertEquals(Ticket::STATUS_COMPLETED, $completedTicket->getStatus());
        $this->assertNotNull($completedTicket->getCompletedAt());
        $this->assertEquals('Demande traitée avec succès pour le test Scrum.', $completedTicket->getNotes());

        // BR02: Completed ticket cannot be called again
        $this->assertFalse($completedTicket->isPending());
    }

    /**
     * US20: Marquer un client comme absent
     */
    public function testAgentMarkClientAbsent(): void
    {
        $client = static::createClient();
        $this->cleanActiveTickets();
        $em = $this->getEntityManager();

        $agent = $em->getRepository(User::class)->findOneBy(['email' => 'agent@queueless.local']);
        $service = $em->getRepository(Service::class)->findOneBy(['code' => 'ACC']);
        $counter = $em->getRepository(Counter::class)->findOneBy(['code' => 'G1']);
        $counter->setCurrentAgent($agent);
        $counter->setService($service);
        $em->flush();

        // Create waiting ticket
        $clientUser = $em->getRepository(User::class)->findOneBy(['email' => 'client@queueless.local']);
        $ticketManager = static::getContainer()->get(\App\Service\TicketManager::class);
        $ticket = $ticketManager->createTicket($clientUser, $service);

        // Agent calls ticket
        $ticketManager->callNextTicket($agent, $counter, $service);

        $client->loginUser($agent);
        $crawler = $client->request('GET', '/agent');
        $this->assertResponseIsSuccessful();

        // Mark absent
        $absentForm = $crawler->selectButton('Client absent (US20)')->form();
        $client->submit($absentForm);
        $this->assertResponseRedirects('/agent');

        $em->clear();
        $absentTicket = $em->getRepository(Ticket::class)->find($ticket->getId());
        $this->assertEquals(Ticket::STATUS_ABSENT, $absentTicket->getStatus());
        $this->assertNotNull($absentTicket->getCompletedAt());
    }
}
