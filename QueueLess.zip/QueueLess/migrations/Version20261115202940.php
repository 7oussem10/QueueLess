<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20261115202940 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE appointment (id INT AUTO_INCREMENT NOT NULL, appointment_reference VARCHAR(50) NOT NULL, appointment_date DATE NOT NULL, start_time TIME NOT NULL, end_time TIME NOT NULL, status VARCHAR(20) NOT NULL, notes LONGTEXT DEFAULT NULL, created_at DATETIME NOT NULL, updated_at DATETIME DEFAULT NULL, service_id INT NOT NULL, client_id INT NOT NULL, counter_id INT DEFAULT NULL, UNIQUE INDEX UNIQ_FE38F8443B29271A (appointment_reference), INDEX idx_apt_date_status (appointment_date, status), INDEX IDX_FE38F844ED5CA9E6 (service_id), INDEX IDX_FE38F84419EB6921 (client_id), INDEX IDX_FE38F844FCEEF2E3 (counter_id), PRIMARY KEY (id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('CREATE TABLE service_schedule (id INT AUTO_INCREMENT NOT NULL, day_of_week SMALLINT NOT NULL, opening_time TIME NOT NULL, closing_time TIME NOT NULL, slot_duration_minutes INT NOT NULL, is_active TINYINT NOT NULL, service_id INT NOT NULL, UNIQUE INDEX uniq_service_day (service_id, day_of_week), INDEX IDX_A34E4AC6ED5CA9E6 (service_id), PRIMARY KEY (id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('ALTER TABLE appointment ADD CONSTRAINT FK_FE38F844ED5CA9E6 FOREIGN KEY (service_id) REFERENCES service (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE appointment ADD CONSTRAINT FK_FE38F84419EB6921 FOREIGN KEY (client_id) REFERENCES `user` (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE appointment ADD CONSTRAINT FK_FE38F844FCEEF2E3 FOREIGN KEY (counter_id) REFERENCES counter (id) ON DELETE SET NULL');
        $this->addSql('ALTER TABLE service_schedule ADD CONSTRAINT FK_A34E4AC6ED5CA9E6 FOREIGN KEY (service_id) REFERENCES service (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE appointment DROP FOREIGN KEY FK_FE38F844ED5CA9E6');
        $this->addSql('ALTER TABLE appointment DROP FOREIGN KEY FK_FE38F84419EB6921');
        $this->addSql('ALTER TABLE appointment DROP FOREIGN KEY FK_FE38F844FCEEF2E3');
        $this->addSql('ALTER TABLE service_schedule DROP FOREIGN KEY FK_A34E4AC6ED5CA9E6');
        $this->addSql('DROP TABLE appointment');
        $this->addSql('DROP TABLE service_schedule');
    }
}
