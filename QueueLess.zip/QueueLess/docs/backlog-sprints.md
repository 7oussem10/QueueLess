# QueueLess — Backlog produit et rapports de sprint

## Priorités du backlog

| ID | User Story | Priorité |
|---|---|---|
| US01 | Consulter les services disponibles | High |
| US02 | Créer un compte client | High |
| US03 | Se connecter | High |
| US04 | Obtenir un ticket | High |
| US05 | Consulter le numéro du ticket | High |
| US06 | Consulter sa position dans la file | High |
| US07 | Consulter le temps d’attente estimé | Medium |
| US08 | Consulter les créneaux disponibles | High |
| US09 | Réserver un rendez-vous | High |
| US10 | Consulter ses rendez-vous | Medium |
| US11 | Annuler un rendez-vous | Medium |
| US12 | Recevoir une notification lorsque son tour approche | Low |
| US13 | Consulter l’historique de ses tickets | Medium |
| US14 | Connexion de l’agent | High |
| US15 | Consulter les tickets en attente | High |
| US16 | Appeler le ticket suivant | High |
| US17 | Consulter les informations d’un ticket | High |
| US18 | Commencer le traitement d’un ticket | High |
| US19 | Terminer le traitement d’un ticket | High |
| US20 | Marquer un client comme absent | Medium |
| US21 | Consulter les rendez-vous du jour | Medium |
| US22 | Consulter l’historique des traitements | Medium |
| US23 | Connexion de l’administrateur | High |
| US24 | Gérer les comptes utilisateurs | High |
| US25 | Attribuer les rôles aux utilisateurs | High |
| US26 | Gérer les services | High |
| US27 | Gérer les guichets | High |
| US28 | Configurer les horaires des services | High |
| US29 | Consulter les statistiques | Low |
| US30 | Consulter l’historique des tickets et rendez-vous | Medium |

## Rapport — Sprint 1

**Dates :** 16/11/2026 – 05/12/2026  
**Sprint Goal :** authentification et gestion des services et guichets.

- **Stories terminées :** US01, US02, US03, US14, US23, US24, US25, US26, US27.
- **Stories non terminées :** aucune story planifiée.
- **Fonctionnalités :** inscription client, connexion par rôle, espaces Client/Agent/Administrateur, administration des comptes et rôles, gestion des services et guichets, consultation publique des services.
- **Tests :** 10 tests, 61 assertions, 0 échec.
- **Problèmes corrigés :** deux liens de navigation pointaient vers des noms de routes inexistants; les accès à l’espace Client acceptaient auparavant les rôles Agent et Administrateur; le formulaire permettait une liste de rôles vide. Les routes, contrôles et validations de rôles ont été corrigés.

## Rapport — Sprint 2

**Dates :** 06/12/2026 – 25/12/2026  
**Sprint Goal :** obtention des tickets et gestion FIFO de la file par les agents.

- **Stories terminées :** US04, US05, US06, US15, US16, US17, US18, US19, US20.
- **Stories non terminées :** aucune story planifiée.
- **Fonctionnalités :** création et consultation des tickets, position dans la file, file d’attente agent, appel FIFO, démarrage et fin de traitement, marquage d’absence.
- **Tests :** 6 tests, 51 assertions, 0 échec.
- **Problèmes corrigés :** les liens de navigation erronés empêchaient le rendu de plusieurs pages Client et Agent; les routes ont été corrigées avant validation.

## Rapport — Sprint 3

**Dates :** 26/12/2026 – 14/01/2027  
**Sprint Goal :** consultation, réservation et gestion des rendez-vous.

- **Stories terminées :** US08, US09, US10, US11, US21, US28.
- **Stories non terminées :** aucune story planifiée.
- **Fonctionnalités :** horaires hebdomadaires par service, créneaux disponibles, réservation, liste et annulation des rendez-vous, vue quotidienne pour Agent et Administrateur.
- **Tests :** 13 tests, 62 assertions, 0 échec.
- **Problèmes corrigés :** validation des heures d’ouverture et fermeture, refus des horaires non proposés ou passés, compatibilité du type d’heure avec Doctrine, correction des tests de formulaire et de jetons CSRF.

## Validation globale

- **Résultat :** 29 tests, 174 assertions, 0 échec, 0 erreur.
- **Contrôles supplémentaires :** syntaxe de 31 templates Twig, conteneur Symfony, syntaxe PHP et YAML.
- **Environnement vérifié :** PHP 8.3.30, Symfony 7.4.23, MySQL 8.4.3.
- **Base queueless_db :** les trois migrations Doctrine du projet sont enregistrées.
- Aucun Sprint 4 n’est planifié ici.
